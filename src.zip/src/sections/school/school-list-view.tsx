'use client';

import { useState, useCallback, useEffect } from 'react';

import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import Tabs from '@mui/material/Tabs';
import Card from '@mui/material/Card';
import Button from '@mui/material/Button';
import Tooltip from '@mui/material/Tooltip';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import IconButton from '@mui/material/IconButton';

import { useRouter } from 'src/routes/hooks';
import { paths } from 'src/routes/paths';

import { useBoolean } from 'src/hooks/use-boolean';
import { useSetState } from 'src/hooks/use-set-state';

import { fIsAfter, fIsBetween } from 'src/utils/format-time';

import { varAlpha } from 'src/theme/styles';
import { DashboardContent } from 'src/layouts/dashboard';

import { Label } from 'src/components/label';
import { toast } from 'src/components/snackbar';
import { Iconify } from 'src/components/iconify';
import { Scrollbar } from 'src/components/scrollbar';
import { ConfirmDialog } from 'src/components/custom-dialog';
import { CustomBreadcrumbs } from 'src/components/custom-breadcrumbs';
import {
  useTable,
  emptyRows,
  rowInPage,
  TableNoData,
  getComparator,
  TableEmptyRows,
  TableHeadCustom,
  TableSelectedAction,
  TablePaginationCustom,
} from 'src/components/table';

import type { SchoolListItem } from 'src/types/services/school';
import { SchoolService } from 'src/services/school';

import { SchoolTableRow } from './school-table-row';
import { SchoolTableToolbar } from './school-table-toolbar';
import { SchoolTableFiltersResult } from './school-table-filters-result';

// ----------------------------------------------------------------------

type ISchoolTableFilters = {
  name: string;
  status: 'all' | 'ok' | 'pending' | 'overdue';
  startDate: Date | null;
  endDate: Date | null;
};

const STATUS_OPTIONS = [
  { value: 'all', label: 'All' },
  { value: 'ok', label: 'OK' },
  { value: 'pending', label: 'Pending' },
  { value: 'overdue', label: 'Overdue' },
];

const TABLE_HEAD = [
  { id: 'name', label: 'School' },
  { id: 'createdAt', label: 'Date', width: 180 },
  { id: 'studentCount', label: 'Students', width: 100, align: 'center' },
  { id: 'courseCount', label: 'Courses', width: 100, align: 'center' },
  { id: 'classCount', label: 'Classes', width: 100, align: 'center' },
  { id: 'teacherCount', label: 'Teachers', width: 110, align: 'center' },
  { id: 'entryPendingCount', label: 'Pending', width: 110, align: 'center' },
  { id: 'entryOverdueCount', label: 'Overdue', width: 110, align: 'center' },
  { id: 'entryReceivedCount', label: 'Received', width: 120, align: 'center' },
  { id: '', width: 88 },
];

// ----------------------------------------------------------------------

export function SchoolListView() {
  // mesma infra do OrderListView
  const table = useTable({ defaultOrderBy: 'name' });

  const router = useRouter();
  const confirm = useBoolean();

  const [tableData, setTableData] = useState<SchoolListItem[]>([]);
  const [loading, setLoading] = useState(false);

  const filters = useSetState<ISchoolTableFilters>({
    name: '',
    status: 'all',
    startDate: null,
    endDate: null,
  });

  const dateError = fIsAfter(filters.state.startDate, filters.state.endDate);

  // ----------------------------------------------------------------------
  // Load inicial (pegamos bastante e paginamos no front igual o mock de orders)
  // ----------------------------------------------------------------------
  const loadSchools = useCallback(async () => {
    try {
      setLoading(true);

      const response = await SchoolService.list({
        page: 1,
        perPage: 1000,
      });

      setTableData(response.schools ?? []);
    } catch (error) {
      // eslint-disable-next-line no-console
      console.error('Erro ao carregar escolas', error);
      toast.error('Erro ao carregar escolas');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadSchools();
  }, [loadSchools]);

  // ----------------------------------------------------------------------
  // Filtro e ordenação (igual ao order, com getComparator + applyFilter)
  // ----------------------------------------------------------------------

  const dataFiltered = applyFilter({
    inputData: tableData,
    comparator: getComparator(table.order, table.orderBy),
    filters: filters.state,
    dateError,
  });

  const dataInPage = rowInPage(dataFiltered, table.page, table.rowsPerPage);

  const canReset =
    !!filters.state.name ||
    filters.state.status !== 'all' ||
    (!!filters.state.startDate && !!filters.state.endDate);

  const notFound = (!dataFiltered.length && canReset) || !dataFiltered.length;

  // ----------------------------------------------------------------------
  // Handlers
  // ----------------------------------------------------------------------

  const handleDeleteRow = useCallback(
    async (id: string) => {
      try {
        await SchoolService.delete(id);
        const newData = tableData.filter((row) => row.id !== id);

        toast.success('School deleted successfully');

        setTableData(newData);
        table.onUpdatePageDeleteRow(dataInPage.length);
      } catch (error) {
        // eslint-disable-next-line no-console
        console.error('Erro ao excluir escola', error);
        toast.error('Erro ao excluir escola');
      }
    },
    [dataInPage.length, table, tableData]
  );

  const handleDeleteRows = useCallback(async () => {
    try {
      await Promise.all(table.selected.map((id) => SchoolService.delete(id).catch(() => null)));

      const newData = tableData.filter((row) => !table.selected.includes(row.id));

      toast.success('Selected schools deleted');

      setTableData(newData);

      table.onUpdatePageDeleteRows({
        totalRowsInPage: dataInPage.length,
        totalRowsFiltered: dataFiltered.length,
      });
    } catch (error) {
      // eslint-disable-next-line no-console
      console.error('Erro ao excluir escolas', error);
      toast.error('Erro ao excluir escolas');
    }
  }, [dataFiltered.length, dataInPage.length, table, tableData]);

  const handleViewRow = useCallback(
    (id: string) => {
      router.push(paths.dashboard.schools.details(id));
    },
    [router]
  );

  const handleFilterStatus = useCallback(
    (_: React.SyntheticEvent, newValue: string) => {
      table.onResetPage();
      filters.setState({ status: newValue as ISchoolTableFilters['status'] });
    },
    [filters, table]
  );

  const handleFiltersChange = useCallback(
    (name: keyof ISchoolTableFilters, value: any) => {
      table.onResetPage();
      filters.setState({ [name]: value } as Partial<ISchoolTableFilters>);
    },
    [filters, table]
  );

  const handleResetFilters = useCallback(() => {
    filters.setState({
      name: '',
      status: 'all',
      startDate: null,
      endDate: null,
    });
    table.onResetPage();
  }, [filters, table]);

  const handleCreate = () => {
    router.push(paths.dashboard.schools.new);
  };

  // ----------------------------------------------------------------------

  return (
    <>
      <DashboardContent>
        <CustomBreadcrumbs
          heading="Schools"
          links={[
            { name: 'Dashboard', href: paths.dashboard.root },
            { name: 'Schools', href: paths.dashboard.schools.root },
            { name: 'List' },
          ]}
          sx={{ mb: { xs: 3, md: 5 } }}
          action={
            <Button
              variant="contained"
              startIcon={<Iconify icon="eva:plus-fill" />}
              onClick={handleCreate}
            >
              New school
            </Button>
          }
        />

        <Card>
          {/* TABS - mesmo esquema do order (All, Pending, Completed...) */}
          <Tabs
            value={filters.state.status}
            onChange={handleFilterStatus}
            sx={{
              px: 2.5,
              boxShadow: (theme) =>
                `inset 0 -2px 0 0 ${varAlpha(theme.vars.palette.grey['500Channel'], 0.08)}`,
            }}
          >
            {STATUS_OPTIONS.map((tab) => (
              <Tab
                key={tab.value}
                iconPosition="end"
                value={tab.value}
                label={tab.label}
                icon={
                  <Label
                    variant={
                      ((tab.value === 'all' || tab.value === filters.state.status) && 'filled') ||
                      'soft'
                    }
                    color={
                      (tab.value === 'ok' && 'success') ||
                      (tab.value === 'pending' && 'warning') ||
                      (tab.value === 'overdue' && 'error') ||
                      'default'
                    }
                  >
                    {tab.value === 'all'
                      ? tableData.length
                      : tableData.filter((school) => {
                          const hasOverdue = school.entryOverdueCount > 0;
                          const hasPending = school.entryPendingCount > 0;

                          if (tab.value === 'overdue') return hasOverdue;
                          if (tab.value === 'pending') return !hasOverdue && hasPending;
                          // ok
                          return !hasOverdue && !hasPending;
                        }).length}
                  </Label>
                }
              />
            ))}
          </Tabs>

          {/* Toolbar igual order (start date, end date, search input) */}
          <SchoolTableToolbar
            filters={filters.state}
            onFiltersChange={handleFiltersChange}
            onResetFilters={handleResetFilters}
            onResetPage={table.onResetPage}
            dateError={dateError}
          />

          {canReset && (
            <SchoolTableFiltersResult
              filters={filters.state}
              totalResults={dataFiltered.length}
              onResetFilters={handleResetFilters}
              onResetPage={table.onResetPage}
              sx={{ p: 2.5, pt: 0 }}
            />
          )}

          <Box sx={{ position: 'relative' }}>
            <TableSelectedAction
              dense={table.dense}
              numSelected={table.selected.length}
              rowCount={dataFiltered.length}
              onSelectAllRows={(checked) =>
                table.onSelectAllRows(
                  checked,
                  dataFiltered.map((row) => row.id)
                )
              }
              action={
                <Tooltip title="Delete">
                  <IconButton color="primary" onClick={confirm.onTrue}>
                    <Iconify icon="solar:trash-bin-trash-bold" />
                  </IconButton>
                </Tooltip>
              }
            />

            <Scrollbar sx={{ minHeight: 444 }}>
              <Table size={table.dense ? 'small' : 'medium'} sx={{ minWidth: 960 }}>
                <TableHeadCustom
                  order={table.order}
                  orderBy={table.orderBy}
                  headLabel={TABLE_HEAD}
                  rowCount={dataFiltered.length}
                  numSelected={table.selected.length}
                  onSort={table.onSort}
                  onSelectAllRows={(checked) =>
                    table.onSelectAllRows(
                      checked,
                      dataFiltered.map((row) => row.id)
                    )
                  }
                />

                <TableBody>
                  {dataFiltered
                    .slice(
                      table.page * table.rowsPerPage,
                      table.page * table.rowsPerPage + table.rowsPerPage
                    )
                    .map((row) => (
                      <SchoolTableRow
                        key={row.id}
                        row={row}
                        selected={table.selected.includes(row.id)}
                        onSelectRow={() => table.onSelectRow(row.id)}
                        onDeleteRow={() => handleDeleteRow(row.id)}
                        onViewRow={() => handleViewRow(row.id)}
                      />
                    ))}

                  <TableEmptyRows
                    height={table.dense ? 56 : 56 + 20}
                    emptyRows={emptyRows(table.page, table.rowsPerPage, dataFiltered.length)}
                  />

                  <TableNoData notFound={notFound && !loading} />
                </TableBody>
              </Table>
            </Scrollbar>
          </Box>

          <TablePaginationCustom
            page={table.page}
            dense={table.dense}
            count={dataFiltered.length}
            rowsPerPage={table.rowsPerPage}
            onPageChange={table.onChangePage}
            onChangeDense={table.onChangeDense}
            onRowsPerPageChange={table.onChangeRowsPerPage}
          />
        </Card>
      </DashboardContent>

      <ConfirmDialog
        open={confirm.value}
        onClose={confirm.onFalse}
        title="Delete"
        content={
          <>
            Are you sure want to delete <strong>{table.selected.length}</strong> schools?
          </>
        }
        action={
          <Button
            variant="contained"
            color="error"
            onClick={() => {
              handleDeleteRows();
              confirm.onFalse();
            }}
          >
            Delete
          </Button>
        }
      />
    </>
  );
}

// ----------------------------------------------------------------------

type ApplyFilterProps = {
  dateError: boolean;
  inputData: SchoolListItem[];
  filters: ISchoolTableFilters;
  comparator: (a: any, b: any) => number;
};

function applyFilter({ inputData, comparator, filters, dateError }: ApplyFilterProps) {
  const { status, name, startDate, endDate } = filters;

  const stabilizedThis = inputData.map((el, index) => [el, index] as const);

  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });

  inputData = stabilizedThis.map((el) => el[0]);

  // filtro por nome
  if (name) {
    inputData = inputData.filter((school) =>
      school.name.toLowerCase().includes(name.toLowerCase())
    );
  }

  // filtro por "status" baseado nos lançamentos
  if (status !== 'all') {
    inputData = inputData.filter((school) => {
      const hasOverdue = school.entryOverdueCount > 0;
      const hasPending = school.entryPendingCount > 0;

      if (status === 'overdue') return hasOverdue;
      if (status === 'pending') return !hasOverdue && hasPending;
      // ok
      return !hasOverdue && !hasPending;
    });
  }

  // filtro de data (createdAt)
  if (!dateError && startDate && endDate) {
    inputData = inputData.filter((school) => fIsBetween(school.createdAt, startDate, endDate));
  }

  return inputData;
}
