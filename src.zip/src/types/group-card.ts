export interface GroupCardItem {
  id: string;
  title: string;
  createdAt: string;
  totalSchools: number;
  totalAdmins: number;
}
