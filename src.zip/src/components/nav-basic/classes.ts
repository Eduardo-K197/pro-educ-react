// ----------------------------------------------------------------------

export const navBasicClasses = {
  desktop: {
    root: 'nav__basic__desktop',
  },
  mobile: {
    root: 'nav__basic__mobile',
  },
};
